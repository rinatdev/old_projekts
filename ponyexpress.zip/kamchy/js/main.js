$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        loop:true,
        items: 1,
        margin: 30,
        navText: ["<i class=\"fas fa-chevron-left\"></i>","<i class=\"fas fa-chevron-right\"></i>"] 
    });
  });